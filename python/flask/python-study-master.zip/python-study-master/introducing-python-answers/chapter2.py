# Q1
seconds_per_minute = 60
minutes_per_hour = 60

seconds_per_minute * minutes_per_hour

# Q2
seconds_per_hour = seconds_per_minute * minutes_per_hour

# Q3
hours_per_day = 24
hours_per_day * seconds_per_hour

# Q4
seconds_per_day = hours_per_day * seconds_per_hour

# Q5
seconds_per_day / seconds_per_hour

# Q6
seconds_per_day // seconds_per_hour

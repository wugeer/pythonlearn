# python-study

我的Python学习代码

## python-samples
我的Python基础练习代码。

  - basic 。 基础练习。
  - sql 。数据库练习
  
## flask-sample

添加了flask的简单例子，演示了基本使用方法。

![运行截图](flask-sample/flask-sample.PNG)

## scrapy_sample
添加了Scrapy爬虫框架的例子。

## introducing-python-answers
《python语言及其应用》的习题答案。

## empireofcode
[Empire of Code](https://checkio.org/)的答案。

## tieba-tools
一点点百度贴吧工具，以后会慢慢补充。
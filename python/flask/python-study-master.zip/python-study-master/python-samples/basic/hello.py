# -*- coding: UTF-8 -*-

# 上面的是文件编码

# 单行注释用井号

'''
多行注释使用三个单引号或双引号
'''

print("Hello world")
